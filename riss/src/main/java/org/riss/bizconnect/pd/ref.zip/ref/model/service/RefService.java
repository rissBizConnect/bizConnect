package org.riss.bizconnect.pd.ref.model.service;

import java.util.ArrayList;

import org.riss.bizconnect.pd.ref.model.dto.RefDTO;

public interface RefService {

	ArrayList<RefDTO> listAllRefs();
	
}
