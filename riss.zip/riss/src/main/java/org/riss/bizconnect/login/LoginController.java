package org.riss.bizconnect.login;

import org.riss.bizconnect.main.member.model.dto.User;
import org.riss.bizconnect.main.member.model.service.MemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller

@RequestMapping("login.do") // 클래스 레벨에서 경로를 설정 
	public class LoginController {

	@Autowired private MemberService memberService; // @Autowired로 memberService주입

	@RequestMapping("loginPage.do")
	public String showLoginPage() {
		return "common/loginPage"; // loginPage.jsp로 이동 
	}


@PostMapping("login.do") // POST 방식으로 login.do 경로로 오는 요청을 처리 
public String login(@RequestParam("gid")String userId,

@RequestParam("user_pw")String userPwd,

@RequestParam("com_code")String comCode,Model model){User user=new User(userId,userPwd,comCode);User authenticatedUser=memberService.selectLogin(user);

if(authenticatedUser!=null){return"redirect:/main";}else{model.addAttribute("error","Invalid credentials. Please try again.");return"loginPage";
}
}
}


 

/*
 * package org.riss.bizconnect.login;
 * 
 * import org.riss.bizconnect.main.member.model.dto.User; import
 * org.riss.bizconnect.main.member.model.service.MemberService; import
 * org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.stereotype.Controller; import
 * org.springframework.ui.Model; import
 * org.springframework.web.bind.annotation.PostMapping; import
 * org.springframework.web.bind.annotation.RequestMapping; import
 * org.springframework.web.bind.annotation.RequestMethod; import
 * org.springframework.web.bind.annotation.RequestParam;
 * 
 * @Controller
 * 
 * @RequestMapping("/login") // Base URL for this controller public class
 * LoginController {
 * 
 * @Autowired private MemberService memberService; // Autowired memberService
 * 
 * // GET request handler for /loginPage.do - shows the login page
 * 
 * @RequestMapping("/loginPage") public String showLoginPage() { return
 * "loginPage"; // Return loginPage.jsp view }
 * 
 * // GET request handler for /login.do - redirect to loginPage.do
 * 
 * @RequestMapping(value = "login.do", method = RequestMethod.GET) public String
 * redirectToLoginPage() { return "redirect:/loginPage.do"; // Redirect GET
 * requests to the login page }
 * 
 * // POST request handler for /login.do - handles login submission
 * 
 * @PostMapping("/login.do") public String login(@RequestParam("gid") String
 * userId,
 * 
 * @RequestParam("user_pw") String userPwd,
 * 
 * @RequestParam("com_code") String comCode, Model model) { User user = new
 * User(userId, userPwd, comCode); User authenticatedUser =
 * memberService.selectLogin(user);
 * 
 * if (authenticatedUser != null) { return "redirect:/main"; // Redirect to main
 * page on success } else { model.addAttribute("error",
 * "Invalid credentials. Please try again."); return "loginPage"; // Return
 * loginPage.jsp with an error message } } }
 */





  