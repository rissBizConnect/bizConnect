package org.riss.bizconnect.main.member.model.dto;

import java.sql.Date; // api ??

public class Member implements java.io.Serializable{

	private static final long serialVersionUID = -8270627500234305220L; // �ø���ѹ�
	
	
	private String gID;				//	GID	VARCHAR2(20 BYTE)
	private String comCode;	//	COM_CODE	VARCHAR2(100 BYTE)
	private String userPw;		//	USER_PW	VARCHAR2(50 BYTE)
	private String userName;	//	USER_NAME	VARCHAR2(20 BYTE)
	private String userJob;		//	USER_JOB	VARCHAR2(20 BYTE)
	private String userRegno;	//	USER_REGNO	VARCHAR2(30 BYTE)
	private String userPhone;	//	USER_PHONE	VARCHAR2(30 BYTE)
	private String userEmail;	//	USER_EMAIL	VARCHAR2(50 BYTE)
	private String userAddr;	//	USER_ADDR	VARCHAR2(100 BYTE)
	private java.sql.Date entryDate; //	USER_ENTRY_DATE	DATE
	private int pay;					//	USER_PAY	NUMBER
	private String	 contract;		//	USER_CONTRACT	VARCHAR2(50 BYTE)
	private String userAccount;//	USER_ACCOUNT	VARCHAR2(50 BYTE)
	private String userCard;	//	USER_CARD	VARCHAR2(50 BYTE)
	private String userRole;	//	USER_ROLE	VARCHAR2(20 BYTE)
	private String userPicture;//	USER_PICTURE	VARCHAR2(255 BYTE)
	
	/*
	private String userId;  //USERID	VARCHAR2(50 BYTE)
	private String userPwd; //USERPWD	VARCHAR2(100 BYTE)
	private String userName; //USERNAME	VARCHAR2(20 BYTE)
	private String gender;  //GENDER	CHAR(1 BYTE)
	private int age;   //AGE	NUMBER(3,0)
	private String phone;  //PHONE	VARCHAR2(13 BYTE)
	private String email;   //EMAIL	VARCHAR2(30 BYTE)
	private java.sql.Date enrollDate;  //ENROLL_DATE	DATE
	private java.sql.Date lastModified;  //LASTMODIFIED	DATE
	private String signType;  //SIGNTYPE	VARCHAR2(10 BYTE)
	private String adminYN;  //ADMIN_YN	CHAR(1 BYTE)
	private String loginOk;  //LOGIN_OK	CHAR(1 BYTE)
	private String photoFileName;  //PHOTO_FILENAME	VARCHAR2(100 BYTE)
	*/
	
	public Member() {
		super();
	}
	public Member(String gID, String comCode, String userPw, String userName, String userJob, String userRegno,
			String userPhone, String userEmail, String userAddr, Date entryDate, int pay, String contract,
			String userAccount, String userCard, String userRole, String userPicture) {
		super();
		this.gID = gID;
		this.comCode = comCode;
		this.userPw = userPw;
		this.userName = userName;
		this.userJob = userJob;
		this.userRegno = userRegno;
		this.userPhone = userPhone;
		this.userEmail = userEmail;
		this.userAddr = userAddr;
		this.entryDate = entryDate;
		this.pay = pay;
		this.contract = contract;
		this.userAccount = userAccount;
		this.userCard = userCard;
		this.userRole = userRole;
		this.userPicture = userPicture;
	}
	public String getgID() {
		return gID;
	}
	public void setgID(String gID) {
		this.gID = gID;
	}
	public String getComCode() {
		return comCode;
	}
	public void setComCode(String comCode) {
		this.comCode = comCode;
	}
	public String getUserPw() {
		return userPw;
	}
	public void setUserPw(String userPw) {
		this.userPw = userPw;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserJob() {
		return userJob;
	}
	public void setUserJob(String userJob) {
		this.userJob = userJob;
	}
	public String getUserRegno() {
		return userRegno;
	}
	public void setUserRegno(String userRegno) {
		this.userRegno = userRegno;
	}
	public String getUserPhone() {
		return userPhone;
	}
	public void setUserPhone(String userPhone) {
		this.userPhone = userPhone;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getUserAddr() {
		return userAddr;
	}
	public void setUserAddr(String userAddr) {
		this.userAddr = userAddr;
	}
	public java.sql.Date getEntryDate() {
		return entryDate;
	}
	public void setEntryDate(java.sql.Date entryDate) {
		this.entryDate = entryDate;
	}
	public int getPay() {
		return pay;
	}
	public void setPay(int pay) {
		this.pay = pay;
	}
	public String getContract() {
		return contract;
	}
	public void setContract(String contract) {
		this.contract = contract;
	}
	public String getUserAccount() {
		return userAccount;
	}
	public void setUserAccount(String userAccount) {
		this.userAccount = userAccount;
	}
	public String getUserCard() {
		return userCard;
	}
	public void setUserCard(String userCard) {
		this.userCard = userCard;
	}
	public String getUserRole() {
		return userRole;
	}
	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}
	public String getUserPicture() {
		return userPicture;
	}
	public void setUserPicture(String userPicture) {
		this.userPicture = userPicture;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "Member [gID=" + gID + ", comCode=" + comCode + ", userPw=" + userPw + ", userName=" + userName
				+ ", userJob=" + userJob + ", userRegno=" + userRegno + ", userPhone=" + userPhone + ", userEmail="
				+ userEmail + ", userAddr=" + userAddr + ", entryDate=" + entryDate + ", pay=" + pay + ", contract="
				+ contract + ", userAccount=" + userAccount + ", userCard=" + userCard + ", userRole=" + userRole
				+ ", userPicture=" + userPicture + "]";
	}
	
	
}
