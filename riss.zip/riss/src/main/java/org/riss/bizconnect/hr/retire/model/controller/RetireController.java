//package org.riss.bizconnect.hr.retire.model.controller;
//
//import java.util.List;
//
//import org.riss.bizconnect.hr.retire.model.dto.Retire;
//import org.riss.bizconnect.hr.retire.model.service.RetireService;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RequestParam;
//
//@Controller
//@RequestMapping("retiree.do") // 기본 URL 매핑
//public class RetireController {
//
//    private static final Logger logger = LoggerFactory.getLogger(RetireController.class);
//    
//    @Autowired
//    private RetireService retireService;
//
//    // 퇴직자 목록 조회 (GET)
//    @RequestMapping("list.do") // 목록 조회 경로
//    public String getRetireeList(Model model) {
//        List<Retire> retireeList = retireService.selectAllRetirees();
//        model.addAttribute("retireeList", retireeList);
//        return "retireeList"; // 반환할 JSP 파일명
//    }
//
//    // 퇴직자 추가 페이지로 이동 (GET)
//    @RequestMapping("add.do") // 퇴직자 추가 페이지 경로
//    public String addRetireeForm() {
//        return "retireeAdd"; // 반환할 JSP 파일명
//    }
//
//    // 퇴직자 추가 처리 (POST)
//    @RequestMapping(value = "add.do", method = RequestMethod.POST) // POST 방식으로 추가
//    public String insertRetiree(Retire retiree) {
//        retireService.insertRetiree(retiree);
//        return "redirect:/retiree/list.do"; // 추가 후 목록으로 리다이렉트
//    }
//
//    // 퇴직자 수정 페이지로 이동 (GET)
//    @RequestMapping(value = "edit.do", method = RequestMethod.GET) // 퇴직자 수정 페이지 경로
//    public String editRetireeForm(@RequestParam("retire_no") int retireId, Model model) {
//        Retire retiree = retireService.selectAllRetirees().stream()
//                          .filter(r -> r.getRetire_no() == retireId)
//                          .findFirst()
//                          .orElse(null);
//        model.addAttribute("retiree", retiree);
//        return "retireeEdit"; // 반환할 JSP 파일명
//    }
//
//    // 퇴직자 수정 처리 (POST)
//    @RequestMapping(value = "edit.do", method = RequestMethod.POST) // POST 방식으로 수정
//    public String updateRetiree(Retire retiree) {
//        retireService.updateRetiree(retiree);
//        return "/retiree/list.do"; // 수정 후 목록으로 리다이렉트
//    }
//
//    // 퇴직자 삭제 (POST)
//    @RequestMapping(value = "delete.do", method = RequestMethod.POST) // POST 방식으로 삭제
//    public String deleteRetiree(@RequestParam("id") int retireId) {
//        retireService.deleteRetiree(retireId);
//        return "/retiree/list.do"; // 삭제 후 목록으로 리다이렉트
//    }
//}
