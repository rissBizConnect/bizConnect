//package org.riss.bizconnect.hr.retire.model.service;
//
//import java.util.ArrayList;
//
//import org.riss.bizconnect.hr.retire.model.dao.RetireDAO;
//import org.riss.bizconnect.hr.retire.model.dto.Retire;
//import org.riss.bizconnect.hr.retire.model.service.RetireService;
//
//public interface RetireService {
//    
//    private RetireDAO retireDAO; // RetireDAO의 인스턴스
//
//    public RetireServiceImpl(RetireDAO retireDAO) {
//        this.retireDAO = retireDAO;
//    }
//
//    @Override
//    public ArrayList<Retire> selectAllRetirees() {
//        return retireDAO.selectAllRetirees();
//    }
//
//    @Override
//    public int insertRetiree(Retire retiree) {
//        return retireDAO.insertRetiree(retiree);
//    }
//
//    @Override
//    public int updateRetiree(Retire retiree) {
//        return retireDAO.updateRetiree(retiree);
//    }
//
//    @Override
//    public int deleteRetiree(int retireId) {
//        return retireDAO.deleteRetiree(retireId);
//    }
//}
