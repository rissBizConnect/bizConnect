//package org.riss.bizconnect.hr.retire.model.service;
//
//import java.util.ArrayList;
//
//import org.riss.bizconnect.hr.retire.model.dao.RetireDAO; // RetireDAO를 import합니다.
//import org.riss.bizconnect.hr.retire.model.dto.Retire; // Retire DTO를 import합니다.
//import org.riss.bizconnect.hr.retire.model.service.RetireService; // RetireService 인터페이스를 import합니다;
//
//public class RetireServiceImpl implements RetireService {
//    
//    private RetireDAO retireDAO; // RetireDAO의 인스턴스
//
//    // 생성자에서 RetireDAO를 주입받습니다.
//    public RetireServiceImpl(RetireDAO retireDAO) {
//        this.retireDAO = retireDAO;
//    }
//
//    // 모든 퇴직자 정보를 조회하는 메소드
//    @Override
//    public ArrayList<Retire> selectAllRetirees() {
//        return retireDAO.selectAllRetirees(); // DAO 메소드를 호출합니다.
//    }
//
//    // 퇴직자를 추가하는 메소드
//    @Override
//    public int insertRetiree(Retire retiree) {
//        return retireDAO.insertRetiree(retiree); // DAO 메소드를 호출합니다.
//    }
//
//    // 퇴직자를 수정하는 메소드
//    @Override
//    public int updateRetiree(Retire retiree) {
//        return retireDAO.updateRetiree(retiree); // DAO 메소드를 호출합니다.
//    }
//
//    // 퇴직자를 삭제하는 메소드
//    @Override
//    public int deleteRetiree(int retireId) {
//        return retireDAO.deleteRetiree(retireId); // DAO 메소드를 호출합니다.
//    }
//}
