//package org.riss.bizconnect.hr.retire.model.dto;
//
//import java.sql.Date;
//
//public class Retire implements java.io.Serializable {
//
//    private static final long serialVersionUID = 1L;
//    
//    private int retire_no;             // 퇴직자 번호
//    private Date user_entry_date;      // 입사일
//    private String ret_type;           // 고용형태
//    private String ret_exitreason;     // 비 고
//    private Date ret_date;             // 퇴사일
//    private Date ret_total_date;       // 총근무일
//    private String gid;                // 로그인아이디
//    private String licenseCode;        // 회사코드
//
//    public Retire() {
//    }
//    
//    public Retire(int retire_no, Date user_entry_date, String ret_type, String ret_exitreason, Date ret_date,
//                  Date ret_total_date, String gid, String licenseCode) {
//        this.retire_no = retire_no;
//        this.user_entry_date = user_entry_date;
//        this.ret_type = ret_type;
//        this.ret_exitreason = ret_exitreason;
//        this.ret_date = ret_date;
//        this.ret_total_date = ret_total_date;
//        this.gid = gid;
//        this.licenseCode = licenseCode;
//    }
//    
//    public int getRetire_no() {
//        return retire_no;
//    }
//    
//    public void setRetire_no(int retire_no) {
//        this.retire_no = retire_no;
//    }
//    
//    public Date getUser_entry_date() {
//        return user_entry_date;
//    }
//    
//    public void setUser_entry_date(Date user_entry_date) {
//        this.user_entry_date = user_entry_date;
//    }
//    
//    public String getRet_type() {
//        return ret_type;
//    }
//    
//    public void setRet_type(String ret_type) {
//        this.ret_type = ret_type;
//    }
//    
//    public String getRet_exitreason() {
//        return ret_exitreason;
//    }
//    
//    public void setRet_exitreason(String ret_exitreason) {
//        this.ret_exitreason = ret_exitreason;
//    }
//    
//    public Date getRet_date() {
//        return ret_date;
//    }
//    
//    public void setRet_date(Date ret_date) {
//        this.ret_date = ret_date;
//    }
//    
//    public Date getRet_total_date() {
//        return ret_total_date;
//    }
//    
//    public void setRet_total_date(Date ret_total_date) {
//        this.ret_total_date = ret_total_date;
//    }
//    
//    public String getGid() {
//        return gid;
//    }
//    
//    public void setGid(String gid) {
//        this.gid = gid;
//    }
//    
//    public String getLicenseCode() {
//        return licenseCode;
//    }
//    
//    public void setLicenseCode(String licenseCode) {
//        this.licenseCode = licenseCode;
//    }
//    
//    @Override
//    public String toString() {
//        return "Retire [retire_no=" + retire_no + 
//                ", user_entry_date=" + user_entry_date + 
//                ", ret_type=" + ret_type +
//                ", ret_exitreason=" + ret_exitreason + 
//                ", ret_date=" + ret_date + 
//                ", ret_total_date=" + ret_total_date + 
//                ", gid=" + gid + 
//                ", licenseCode=" + licenseCode + "]";
//    }
//}
